<!-- Footer starts -->
<!-- Bootstrap JS -->
 <script src="style/js/bootstrap.min.js"></script>  
<div id="push"></div>
    </div>
      <footer>
         <div class="container">
         
            <div class="cvcopy text-center">
               <p>Affiliate Portal Envato - Powered By <a href="http://www.nexthon.com">Nexthon.</a> - 
               <a href="<?php echo rootpath() . "/contact/" ?>">Contact Us.</a><br /> <small>envato&reg; is registered trademark of <a href="http://www.envato.com/">Envato Corporation.</a></small> </p>
            </div>
            
         </div>
        
      </footer>
      </body>
      <!-- Footer ends -->
