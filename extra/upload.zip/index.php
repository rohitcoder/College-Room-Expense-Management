<?php
error_reporting(0);
include("include/Config.php");
$app = new App();
$app->run();
?>