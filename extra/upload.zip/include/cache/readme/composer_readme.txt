https://packagist.org/packages/phpfastcache/phpfastcache
<-- look at this page for versions

{
    require: {
        "phpfastcache/phpfastcache": "2.4.2"
    }
}
